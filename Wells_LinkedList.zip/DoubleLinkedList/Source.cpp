//Doubly Linked List implementation by Matthew Wells
#include<iostream>

using std::cout;
using std::endl;

template <typename N> //N is a generic datatype- specify its type when declaring a node

class WellsLinkedList //A doubly linked list. To prevent memory leak or loss, call nodes in it on the heap rather than the stack.
{
public:
    WellsLinkedList* parent = NULL; //Prior node in the list
    WellsLinkedList* child = NULL; //Following node in the list
    N value; //Value of this node

    WellsLinkedList() {}; //A node can be initialized with no values- this results in a value of null and no parent or child

    WellsLinkedList(N data) //When initialized with one parameter, a node sets that parameter to its value
    {
        value = data;
    };

    WellsLinkedList(WellsLinkedList* parent, N data) //When initialized with two parameters, the first parameter is set to be the parent, and the second the value
    {
        parent = parent;
        value = data;
    };

    void Insert(N data) //Adds a new node to the heap and places it at the end of the list. Takes one paramater for the value of the new node.
    {
        if (child == NULL)
        {
            child = new WellsLinkedList<N> (this, data);
            child->parent = this;
        }
        else
        {
            child->Insert(data);
        }
    };

    void InsertAfter(WellsLinkedList* node) //Inserts a node into the list immediately after the current node. Takes an already initialized node as a parameter.
    {
        if (child != NULL)
        {
            WellsLinkedList* oldChild = child;
            child = node;
            child->parent = this;
            child->InsertAfter(oldChild);
        }
        else
        {
            child = node;
            child->parent = this;
        }
    };

    void InsertBefore(WellsLinkedList* node) //Inserts a node into the list immediately before the current node. Takes an already initialized node as a parameter.
    {
        if (parent != NULL)
        {
            parent->InsertAfter(node);
        }
        else
        {
            parent = node;
            parent->child = this;
        }
    }

    WellsLinkedList* Find(N key, bool searchUp = true, bool iterating = false)
        //If key is in the linkedlist, returns a pointer a node containing it, otherwise returns a null pointer.
        //Favors nodes prior to this one, and favors proximity to this node.
    {
        WellsLinkedList* returnPointer = NULL;
        if (key == value)
        {
            returnPointer = this;
            return returnPointer;
        }
        if (!iterating)
        {
            if (parent != NULL)
            {
                returnPointer = parent->Find(key, true, true);
            }
            if (returnPointer != NULL)
            {
                return returnPointer;
            }
            else if (child != NULL)
            {
                returnPointer = child->Find(key, false, true);
            }
            return returnPointer;
        }
        else
        {
            if (searchUp)
            {
                if (parent != NULL)
                {
                    returnPointer = parent->Find(key, true, true);
                }
                return returnPointer;
            }
            else
            {
                if (child != NULL)
                {
                    returnPointer = child->Find(key, false, true);
                }
                return returnPointer;
            }
        }
    };

    void Delete(WellsLinkedList* delNode) //Removes a node from both the list and the heap.
    {
        if (delNode->child != nullptr)
        {
            delNode->child->parent = delNode->parent;
        }
        if (delNode->parent != nullptr)
        {
            delNode->parent->child = delNode->child;
        }
        delete delNode;
    };

    N Maximum() //Returns the highest value key in the list. Called without a parameter, it recurses to the beginning of the list to begin searching
    {
        if (parent != NULL)
        {
            return parent->Maximum();
        }
        else if (child != NULL)
        {
            return child->Maximum(value);
        }
        else
        {
            return value;
        }
    };

    N Maximum(N curMax) //Recursively searches through the list for the highest value key and returns it.
    {
        if (curMax < value)
        {
            curMax = value;
        }
        if (child == NULL)
        {
            return curMax;
        }
        else
        {
            return child->Maximum(curMax);
        }
    };

    N Minimum() //Returns the lowest value key in the list. Called without a parameter, it recurses to the beginning of the list to begin searching
    {
        if (parent != NULL)
        {
            return parent->Minimum();
        }
        else if (child != NULL)
        {
            return child->Minimum(value);
        }
        else 
        {
            return value;
        }
    };

    N Minimum(N curMin) //Recursively searches through the list for the lowest value key and returns it.
    {
        if (curMin > value)
        {
            curMin = value;
        }
        if (child == NULL)
        {
            return curMin;
        }
        else
        {
            return child->Minimum(curMin);
        }
    };
};

int main() //Demonstration of functionality
{
    WellsLinkedList<int>* integerList = new WellsLinkedList<int> (); //Generate a new list of integers
    integerList->value = 11; //Set the only node in the list's value to 11
    integerList->Insert(42); //Append a new node to the list with value 42
    WellsLinkedList<int>* preList = new WellsLinkedList<int>(134); //Create a node with a value of 134
    integerList->InsertBefore(preList); //Put the node with value 134 at the beginning of the list
    WellsLinkedList<int>* midListNode = new WellsLinkedList<int> (22); //Create a node with value 22
    integerList->InsertAfter(midListNode); //Insert the node with value 22 into the list after the original node
    cout << integerList->Find(134) << endl; //Return the pointer to the node with value 134 in the list, if it exists
    cout << integerList->Maximum() << endl; //Return the highest value key in the list
    cout << integerList->Minimum() << endl; //Return the lowest value key in the list
    integerList->Delete(integerList->Find(134)); //Delete the first node found with a value of 134 in the list
    cout << integerList->Maximum() << endl;
    WellsLinkedList<char>* characterList = new WellsLinkedList<char>();
    characterList->value = 'e';
    characterList->Insert('t');
    WellsLinkedList<char>* preChar = new WellsLinkedList<char>('T');
    characterList->InsertBefore(preChar);
    WellsLinkedList<char>* midListChar = new WellsLinkedList<char>('s');
    characterList->InsertAfter(midListChar);
    cout << characterList->Find('e') << endl;
    cout << characterList->Maximum() << endl;
    cout << characterList->Minimum() << endl;
    characterList->Delete(midListChar);
    cout << characterList->Find('s');
};